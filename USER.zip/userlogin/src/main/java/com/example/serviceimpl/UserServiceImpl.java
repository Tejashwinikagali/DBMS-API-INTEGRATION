package com.example.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.User;
import com.example.model.UserDTO;
import com.example.repository.UserRepository;
import com.example.service.UserService;
import com.example.util.Converter;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
	private UserRepository userRepository;
	@Autowired
	private Converter converter;
	
	public UserDTO saveUser(User user)
	{
       return converter.convertUserTOUserDTO(userRepository.save(user));
	}
    public List<UserDTO> getAllUsers()
    
    {
    	List<User> users = userRepository.findAll();
    	
    	List<UserDTO> userdto = new ArrayList<>();
    	
    	for(User user : users)
    	{
    		userdto.add(converter.convertUserTOUserDTO(user));
    		
    	}
    	return userdto;
    }
    
    //
    public UserDTO updateUser(int id,User user) {
    	User existingUser = userRepository.findById(id).get();
    	 existingUser.setUsername(user.getUsername());
    	 existingUser.setEmail(user.getEmail());
    	 existingUser.setPassword(user.getPassword());
    	 
    	 return converter.convertUserTOUserDTO(userRepository.save( existingUser));
    }
    
    public String deactivateUser(int userId) {
    	userRepository.deleteById(userId);
    	return "The user's account has been deactivated.";
    }
	@Override
	public List<UserDTO> getAllUser() {
		// TODO Auto-generated method stub
		return null;
	}
    
}

