package com.example.testing;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class FirstProgram1 {
	@RequestMapping("/demo")
	@ResponseBody
	public String show()
	{
		return "Good Morning!..";
	
	}
	
	
	

}
