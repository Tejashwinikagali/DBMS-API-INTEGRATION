package com.example.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.example.entity.User;
import com.example.model.UserDTO;

@Component
public class Converter {
	public User convertUserDTOTouser(UserDTO userdto)
	{
		User user = new User();
		
		if(userdto!=null)
		{
			BeanUtils.copyProperties(userdto, user);
		}
		return user; 
	}
  
	 //convert from entity to dto
	public UserDTO convertUserTOUserDTO(User user)
	{
		UserDTO userdto = new UserDTO();
		
		if(user!=null)
		{
			BeanUtils.copyProperties(user, userdto);
		}
		return userdto;
	}
}
